import './script/components/header.js';
import './script/components/footer.js';
import './script/components/note-form.js';
import './script/components/note-item.js';
import './script/components/note-list.js';
import './script/components/loading-indicator.js';
import './styles/style.css';
